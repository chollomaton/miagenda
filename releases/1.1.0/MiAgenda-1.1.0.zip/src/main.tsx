import './styles/base.css';
import './styles/tokens.css';
import './styles/native.css';

async function start() {
  const container = document.getElementById('root');
  if (!container) throw new Error('Missing root container');
  const [{ createRoot }, { StrictMode }, { StartupApp }, { ErrorBoundary }] = await Promise.all([
    import('react-dom/client'), import('react'), import('./app/StartupApp'), import('./components/ErrorBoundary'),
  ]);
  createRoot(container).render(<StrictMode><ErrorBoundary><StartupApp /></ErrorBoundary></StrictMode>);
}

void start().catch(() => {
  const message = document.createElement('p');
  message.setAttribute('role', 'alert');
  message.textContent = 'No se ha podido iniciar Mi Agenda. Recarga la página para volver a intentarlo.';
  (document.getElementById('root') ?? document.body).replaceChildren(message);
});
